sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"ZSHELL_PLUG/util/Formatter"
], function(Controller, formatter) {
	"use strict";

	return Controller.extend("ZSHELL_PLUG.controller.App", {
		onInit: function() {

			var oRendererExtensions = jQuery.sap.getObject("sap.ushell.renderers.fiori2.RendererExtensions");
			var _this = this;
			this.listModel = new sap.ui.model.json.JSONModel();
			this._oPopover = null;
			// console.log(oRendererExtensions);
			oRendererExtensions.setHeaderTitle("Last Mile Smart Logistics");
			var button1 = new sap.ushell.ui.shell.ShellHeadItem({
				icon: "sap-icon://history",
				press: function(oEVent) {
					_this.pressVersioning(oEVent);
				}
			});
			var renderer = sap.ushell.Container.getRenderer("fiori2");
			renderer.showHeaderEndItem([button1.getId()], false, ['home', 'app']);
		},

		pressVersioning: function(oEvent) {
			var _this = this;
			if (!_this._oPopover) {
				_this._oPopover = sap.ui.xmlfragment("SpotFragment", "ZSHELL_PLUG.view.Popover", this);
				_this.getView().addDependent(_this._oPopover);
			}
			_this.listModel.setData({
				VersionCollection: [{
					VersionNo: "1.0",
					VersionName: "Version 2.0",
					Status: "Active",
					ReleaseDate: "21/08/2016"
				} ]
			});
			_this._oPopover.setModel(_this.listModel);
			_this._oPopover.openBy(oEvent.getSource());

		}
	});

});