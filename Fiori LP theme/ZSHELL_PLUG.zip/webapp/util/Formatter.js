sap.ui.define(function() {
	"use strict";

	var Formatter = {

		status : function(sStatus) {
			if (sStatus === "Active") {
				return "Success";
			} else if (sStatus === "InActive") {
				return "Warning";
			} else if (sStatus === "InValid") {
				return "Error";
			} else {
				return "None";
			}
		},
		
		favorite : function(sStatus){
		if (sStatus === "Active") {
				return true;
			} else {
				return false;
			}	
		}
	};

	return Formatter;

}, /* bExport= */ true);