// jQuery.sap.require("ZCUSTOMTILE.util.Formatter");

sap.ui.controller("ZCUSTOMTILE.webapp.controller.Tile", {

	// sURI: jQuery.sap.getModulePath("ZCUSTOMTILE") +'/destinations/northwind/V3/Northwind/Northwind.svc/',
	// oModel: null,
	// counter: 0,
	// employeeArray: null, 

	/**
	 * Called when a controller is instantiated and its View controls (if available) are already created.
	 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
	 * @memberOf view.Tile
	 */
	onInit: function() {
		this.tileModel = new sap.ui.model.json.JSONModel();
		this.tile = this.getView().byId("genericTile");
		this.tile.setModel(this.tileModel);
		this.tile.setState(sap.suite.ui.commons.LoadState.Loading);
		var _this = this;
		setInterval(function() {
				_this.loadData();
			},
			5000);

	},

	/**
	 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
	 * (NOT before the first rendering! onInit() is used for that one!).
	 * @memberOf view.Tile
	 */
	//	onBeforeRendering: function() {
	//
	//	},

	/**
	 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
	 * This hook is the same one that SAPUI5 controls get after being rendered.
	 * @memberOf view.Tile
	 */
	onAfterRendering: function() {
		var _this = this;
		_this.tile.setState(sap.suite.ui.commons.LoadState.Loading);
		jQuery.ajax({
			// type: "GET",
			contentType: "application/json",
			url: "/sap/fiori/updel/gwhcp/odata/SAP/ZSALES_ORDER_STATUS_SRV/so_statusSet('1')?$format=json",
			//url: "/sap/fiori/ziotservices/destinations/HANAXS/s0004806408trial/dev/iotservices/iotservices_number_sts.xsjs",
			dataType: "json",
			success: function(data, textStatus, jqXHR) {
				var sopen;
					var sclose;
					var total;
					var opnpr;
					var closepr;
					sopen = data.d.SoOpen;
					sclose = data.d.SoClose;
					sopen = parseInt(sopen);
					sclose = parseInt(sclose);
					total = sopen + sclose;
					opnpr = sopen/total;
					closepr = sclose/total;
					opnpr = opnpr * 100;
					closepr = closepr * 100;
					opnpr = opnpr.toFixed(2);
					closepr = closepr.toFixed(2);
					opnpr = parseFloat(opnpr);
					closepr = parseFloat(closepr);
					var data1 = [
    {"state":"Good", "text":"In Process", "number":opnpr},
    {"state":"Error", "text":"Completed", "number":closepr}
   
];
				_this.tileModel.setData({
					Data: data1
				});
				_this.tile.setState(sap.suite.ui.commons.LoadState.Loaded);
			},
			error: function() {
				_this.tile.setState(sap.suite.ui.commons.LoadState.Failed);
			}
		});
		// var view = this.getView();
		//   var oViewData = view.getViewData();
		//   var genericTile = view.byId(view.createId("genericTile"));
		//   if(oViewData !== undefined && oViewData.properties !== undefined ){
		//       var titleTextVar = oViewData.properties && oViewData.properties.titleText;
		//       genericTile.setHeader( titleTextVar )
		//   }
		//   else{
		//       genericTile.setHeader("Get to know your colleagues...")
		//   }

		//   this.oModel = new sap.ui.model.odata.ODataModel(this.sURI, true);
		//   var parameters = {};
		//   parameters.async = true;
		//   var that = this;
		//   parameters.error = function(){

		//   };

		//   parameters.success = function(oData, response){

		// 	if(response.statusCode === 200){

		//           var controller = that;
		//           var view = controller.getView();
		// 		controller.employeeArray = oData.results;
		// 		var genericTile = view.byId(view.createId("genericTile"));

		// 		var jsonModel = new sap.ui.model.json.JSONModel();
		// 		 jsonModel.setData({modelData: oData.results});
		// 		 view.setModel(jsonModel);

		//   	    var empArr = controller.employeeArray;
		//   	    var internalCounter  = controller.counter + 1;
		//   	    genericTile.bindElement("/modelData/0");

		//          setInterval(function(){ 

		//               debugger;
		//               if(internalCounter === empArr.length ){
		//                   internalCounter = 0;
		//               }
		//               genericTile.bindElement("/modelData/" + internalCounter);
		//               internalCounter+=1;
		//               }, 
		//               5000);

		// 	}

		// };
		//    this.oModel.read("/ZCUSTOMTILE", parameters);
	},
	
	loadData : function(){
		var _this = this;
		jQuery.ajax({
			// type: "GET",
			contentType: "application/json",
			//url: "/sap/fiori/ziotservices/destinations/HANAXS/s0004806408trial/dev/iotservices/iotservices_number_sts.xsjs",
			url: "/sap/fiori/updel/gwhcp/odata/SAP/ZSALES_ORDER_STATUS_SRV/so_statusSet('1')?$format=json",
			dataType: "json",
			success: function(data, textStatus, jqXHR) {
				var sopen;
					var sclose;
					var total;
					var opnpr;
					var closepr;
					sopen = data.d.SoOpen;
					sclose = data.d.SoClose;
					sopen = parseInt(sopen);
					sclose = parseInt(sclose);
					total = sopen + sclose;
					opnpr = sopen/total;
					closepr = sclose/total;
					opnpr = opnpr * 100;
					closepr = closepr * 100;
					opnpr = opnpr.toFixed(2);
					closepr = closepr.toFixed(2);
					opnpr = parseFloat(opnpr);
					closepr = parseFloat(closepr);
					
					var data2 = [
    {"state":"Good", "text":"In Process", "number":opnpr},
     {"state":"Error", "text":"Completed", "number":closepr}
   
];
				_this.tileModel.setData({
					Data: data2
				});
				
			},
			error: function() {
				_this.tile.setState(sap.suite.ui.commons.LoadState.Failed);
			}
		});
		
	},
	onPress: function() {
		// debugger;
		var oStaticTileView = this.getView(),
			oViewData = oStaticTileView.getViewData(),
			navTargetUrl = oViewData.properties && oViewData.properties.navigation_target_url;

		if (navTargetUrl) {
			if (navTargetUrl[0] === '#') {
				hasher.setHash(navTargetUrl);
			} else {
				window.open(navTargetUrl, '_blank');
			}
		}
	}

	/**
	 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
	 * @memberOf view.Tile
	 */
	//	onExit: function() {
	//
	//	}

});