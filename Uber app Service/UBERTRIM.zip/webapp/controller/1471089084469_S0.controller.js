sap.ui.define([
		'jquery.sap.global', 
		'sap/m/MessageToast',
		'sap/ui/core/mvc/Controller',
		'sap/ui/model/json/JSONModel'
	], function(jQuery, MessageToast, Controller, JSONModel) {
	"use strict";
 
	var ListController = Controller.extend("generated.app.controller.1471089084469_S0", {
 
		onInit: function () {
			// set mock model
			sap.ui.core.BusyIndicator.show(1);
			var _this = this;
			
		
		
			  
			  //var coords = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
			// set route options (draggable means you can alter/drag the route in the map)
			  
			
			//var lat = position.coords.latitude;
			//var long = position.coords.longitude;
			var JSONModel = new sap.ui.model.json.JSONModel();
            _this.getView().setModel(JSONModel);
			 	var url = "/destinations/UBER/v1.2/history?limit=50"; 
			  	$.ajax({
				type: "GET",
				contentType: "application/json",
				url: url,
				headers: {
					"Authorization": "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzY29wZXMiOlsicHJvZmlsZSIsImhpc3RvcnlfbGl0ZSIsInJlcXVlc3QiLCJwbGFjZXMiLCJoaXN0b3J5Il0sInN1YiI6ImFkYTFhMzg4LTI5MDktNDhmMi1iMjc4LTMwMDUxMmQ4MjM5NCIsImlzcyI6InViZXItdXMxIiwianRpIjoiYTE3MjNkODgtMzlkNy00OWJlLTlhYmItNDU0YjQwYjA1NjhjIiwiZXhwIjoxNDczNDU2NTk3LCJpYXQiOjE0NzA4NjQ1OTYsInVhY3QiOiJmY0pVcnRWTm5LSGhzdFZXbzVEa2RVNzZDWGwxeXoiLCJuYmYiOjE0NzA4NjQ1MDYsImF1ZCI6InRXTTg0dFltOU93YkJocFhlVHlXUnJ5WE1Gb0c2QlVMIn0.cm_HvD_qAEzFWSIat7Ema33BsNl22hQVhVPoNtONAmJScvbOUxsVyAJkdm2zEUtqh1-ILwVIAqhoHDG2aHS-XJVKI3-swC_bFiyMdVZAlxUh7JwPrg9Ipb6TCuH4Fi_YrzN971kjfzMk4VR902FLg0UJ_c_JTTu48FaS7NUgcSsBVP81JVjDgJUmfeQ4SFOwGu1qVAafR-0bedLLXXUk_8fyiF56rZk0F1pOM_YKz1nwA94KEo_sTf8mMqrSTJew8K2C3u19WvgNR-ZQcgv2hZTJOICsgbIks1mSLXW0yuoIDVfRC5y14AOvXe13J4fjIAD3m41asfOi0C0PWzKY3A"

				},
				success: function(data, textStatus, jqXHR) {

					// alert("success to post");
					// console.log("data");
					console.log(data);
					JSONModel.setData(data);
					//alert("Success");
sap.ui.core.BusyIndicator.hide();
				},
				error: function() {
					alert("Error");
				}
			  

			  
			  
			});
			
		

			//navigator.geolocation.getCurrentPosition(positionCallback);
			// var table = this.getView().byId("idProductsTable");
			// var lat;
			// var long;
			// var JSONModel = new sap.ui.model.json.JSONModel();
			// table.setModel(JSONModel);

		

		
		

		
		
		},
 
		onPress: function (oEvent) {
			MessageToast.show("Clicked on " + oEvent.getSource().getSender());
		}
	});
 
 
	return ListController;
 
});