sap.ui.define([
		'jquery.sap.global',
		'sap/ui/core/mvc/Controller',
		'sap/ui/model/json/JSONModel'
	], function(jQuery, Controller, JSONModel) {
	"use strict";
              
	var ListController = Controller.extend("UBERPRO.controller.View1", {
 
		onInit : function (evt) {
             var _this = this;
             var lat1 = "";
             var long1 ="";

			// set explored app's demo model on this sample
	sap.ui.core.BusyIndicator.show(1);
if (navigator.geolocation) {
			  navigator.geolocation.getCurrentPosition(success);
			} 
// 				function errorCoor(error){
			
// 			 switch(error.code) {
// 		        case error.PERMISSION_DENIED:
// 		            x = "User denied the request for Geolocation."
// 		            break;
// 		        case error.POSITION_UNAVAILABLE:
// 		            x = "Location information is unavailable."
// 		            break;
// 		        case error.TIMEOUT:
// 		            x = "The request to get user location timed out."
// 		            break;
// 		        case error.UNKNOWN_ERROR:
// 		            x = "An unknown error occurred."
// 		            break;
// 		    }
// 			 alert(x);
			
// 		}; 

function success(position) {
			  
			  //var coords = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
			// set route options (draggable means you can alter/drag the route in the map)
			  
			
			 var lat = position.coords.latitude;
			 var long = position.coords.longitude;
			 lat1 = lat;
			 long1 = long;

			
		

			//navigator.geolocation.getCurrentPosition(positionCallback);
			// var table = this.getView().byId("idProductsTable");
			// var lat;
			// var long;
			// var JSONModel = new sap.ui.model.json.JSONModel();
			// table.setModel(JSONModel);

		

		
		

		}
					var JSONModel = new sap.ui.model.json.JSONModel();
            _this.getView().setModel(JSONModel);
            //var url = "/destinations/HCPSERVICE/p1941877974trial/relayrlk3";
            if (lat1 === "" ) {
            	lat1 = '12.9922';
            	long1 = '77.7159';
            }
			  
			  	var url = "/destinations/UBER/v1/products?latitude="+lat1+"&longitude="+long1;
			$.ajax({
				type: "GET",
				contentType: "application/json",
				url: url,
				headers: {
					"Authorization": "Token OU0ijgdEoNof_wf01rFGFBOd_1ZayIOKFX8argni"

				},
				success: function(data, textStatus, jqXHR) {

					// alert("success to post");
					// console.log("data");
					console.log(data);
					JSONModel.setData(data);
					//alert("Success");
                     sap.ui.core.BusyIndicator.hide();
				},
				error: function() {
					alert("Error");
				}
			  

			  
			  
			});
			
		}
	});
 
 
	return ListController;
 
});