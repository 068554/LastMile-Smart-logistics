jQuery.sap.require("UBERSHIP.util.Formatter");
jQuery.sap.require("UBERSHIP.util.Controller");

UBERSHIP.util.Controller.extend("UBERSHIP.view.Detail", {

	/**
	 * Called when the detail list controller is instantiated. 
	 */
	onInit: function() {
		this.oInitialLoadFinishedDeferred = jQuery.Deferred();

		if (sap.ui.Device.system.phone) {
			//don't wait for the master on a phone
			this.oInitialLoadFinishedDeferred.resolve();
		} else {
			this.getView().setBusy(true);
			this.getEventBus().subscribe("Master", "InitialLoadFinished", this.onMasterLoaded, this);
		}

		this.getRouter().attachRouteMatched(this.onRouteMatched, this);

	},

	/**
	 * Master InitialLoadFinished event handler
	 * @param{String} sChanel event channel name
	 * @param{String}} sEvent event name
	 * @param{Object}} oData event data object
	 */
	onMasterLoaded: function(sChannel, sEvent, oData) {
		var _this = this;
		var table = _this.getView().byId("sensorid");
		var JSONModel = new sap.ui.model.json.JSONModel();
		table.setModel(JSONModel);
		// sap.ui.getCore().getModel().refresh(true);
		//Code added 
		// setInterval(function(){
		// 	// console.log("data");
  //      JSONModel.refresh(true);
  //      },500);

		var wifi;
		var accelero_x;
		var accelero_y;
		var accelero_z;
		var modacc;
		var lumono;
		var batt;
		var angulr_x;
		var angulr_y;
		var angulr_z;
		var modang;
		var temp;
	//	var JSONModel = new sap.ui.model.json.JSONModel();
		var oModel = new sap.ui.model.json.JSONModel();
			setInterval(function(){
			// console.log("data");
        oModel.refresh(true);
        },500);
		table.setModel(oModel);
		
		var url = "/destinations/HCPSERVICE/p1941877974trial/relayrlk3";

		// var url = "/destinations/UBER/v1/products?latitude="+lat+"&longitude="+long;
		$.ajax({
			type: "GET",
			contentType: "application/json",
			url: url,
			// headers: {
			// 	"Authorization": "Token OU0ijgdEoNof_wf01rFGFBOd_1ZayIOKFX8argni"

			// },
			success: function(data, textStatus, jqXHR) {

				// alert("success to post");
				// console.log("data");
				console.log(data);
				wifi = data.readings[0].value;
				lumono = data.readings[3].value;
				temp = 14 + (lumono/10);
				batt = data.readings[5].value;
				angulr_x = data.readings[4].value.x;
				angulr_y = data.readings[4].value.y;
				angulr_z = data.readings[4].value.z;
				angulr_x = angulr_x * angulr_x;
				angulr_y = angulr_y * angulr_y;
				angulr_z = angulr_z * angulr_z;
				modang = angulr_x + angulr_x + angulr_x;
				modang = Math.sqrt(modang);
				accelero_x = data.readings[1].value.x;
				accelero_y = data.readings[1].value.y;
				accelero_z = data.readings[1].value.z;
				accelero_x = accelero_x * accelero_x;
				accelero_y = accelero_y * accelero_y;
				accelero_z = accelero_z * accelero_z;
				modacc = accelero_x + accelero_x + accelero_x;
				modacc = Math.sqrt(modacc);
				oModel.setData({
						sensor: [{
								"sname": "Wireless",
								"value": wifi,
								"unit": "dbm"

							}, {
								"sname": "Lumonosity",
								"value": lumono,
								"unit": "L⊙"
							}, {
								"sname": "Battery",
								"value": batt,
								"unit": "kWh",
							}, {
								"sname": "Acceleration",
								"value": modacc,
								"unit": "m/s-2"
							}, {
								"sname": "Angular Speed",
								"value": modang,
								"unit": "m/s"
							},
							{
								"sname": "Temperature",
								"value": temp,
								"unit": "C"
							}

						]

					}

				);

				JSONModel.setData(data);
				//alert("Success");

			},
			error: function() {
				alert("Error");
			}

		});
		if (oData.oListItem) {
			this.bindView(oData.oListItem.getBindingContext().getPath());
			this.getView().setBusy(false);
			this.oInitialLoadFinishedDeferred.resolve();
		}
	},

	/**
	 * Detail view RoutePatternMatched event handler 
	 * @param{sap.ui.base.Event} oEvent router pattern matched event object
	 */
	onRouteMatched: function(oEvent) {
		var oParameters = oEvent.getParameters();

		jQuery.when(this.oInitialLoadFinishedDeferred).then(jQuery.proxy(function() {
			var oView = this.getView();

			// when detail navigation occurs, update the binding context
			if (oParameters.name !== "detail") {
				return;
			}

			var sEntityPath = "/" + oParameters.arguments.entity;
			this.bindView(sEntityPath);

			var oIconTabBar = oView.byId("idIconTabBar");
			oIconTabBar.getItems().forEach(function(oItem) {
				oItem.bindElement(UBERSHIP.util.Formatter.uppercaseFirstChar(oItem.getKey()));
			});

			// Which tab?
			var sTabKey = oParameters.arguments.tab;
			this.getEventBus().publish("Detail", "TabChanged", {
				sTabKey: sTabKey
			});

			if (oIconTabBar.getSelectedKey() !== sTabKey) {
				oIconTabBar.setSelectedKey(sTabKey);
			}
		}, this));

	},

	/**
	 * Binds the view to the object path.
	 * @param {string} sEntityPath path to the entity
	 */
	bindView: function(sEntityPath) {
		var oView = this.getView();
		oView.bindElement(sEntityPath);

		//Check if the data is already on the client
		if (!oView.getModel().getData(sEntityPath)) {

			// Check that the entity specified actually was found.
			oView.getElementBinding().attachEventOnce("dataReceived", jQuery.proxy(function() {
				var oData = oView.getModel().getData(sEntityPath);
				if (!oData) {
					this.showEmptyView();
					this.fireDetailNotFound();
				} else {
					this.fireDetailChanged(sEntityPath);
				}
			}, this));

		} else {
			this.fireDetailChanged(sEntityPath);

		}

	},

	/**
	 * display NotFound view
	 */
	showEmptyView: function() {
		this.getRouter().myNavToWithoutHash({
			currentView: this.getView(),
			targetViewName: "UBERSHIP.view.NotFound",
			targetViewType: "XML"
		});
	},

	/**
	 * publish Detail Changed event
	 */
	fireDetailChanged: function(sEntityPath) {
		var status = this.getView().getModel().getData(sEntityPath).STATUS;

		if (status != "in_progress") {
			this.getView().byId("sensorid").setVisible(false);
		} else {
			this.getView().byId("sensorid").setVisible(true);
			// this.refresh();
		}

		this.getEventBus().publish("Detail", "Changed", {
			sEntityPath: sEntityPath
		});
	},
	// 	refresh:function(){
		
	// 	console.log("refresh");
	// 		var _this = this;
	// 	var table = _this.getView().byId("sensorid");
	// 	var JSONModel = new sap.ui.model.json.JSONModel();
	// 	table.setModel(JSONModel);
	// 	// sap.ui.getCore().getModel().refresh(true);
	// 	//Code added 
	// 	// setInterval(function(){
	// 	// 	// console.log("data");
 // //      JSONModel.refresh(true);
 // //      },500);

	// 	var wifi;
	// 	var accelero_x;
	// 	var accelero_y;
	// 	var accelero_z;
	// 	var modacc;
	// 	var lumono;
	// 	var batt;
	// 	var angulr_x;
	// 	var angulr_y;
	// 	var angulr_z;
	// 	var modang;
	// 	var temp;
	// //	var JSONModel = new sap.ui.model.json.JSONModel();
	// 	var oModel = new sap.ui.model.json.JSONModel();
	// 		setInterval(function(){
	// 		// console.log("data");
 //       oModel.refresh(true);
 //       },500);
	// 	table.setModel(oModel);
		
	// 	var url = "/destinations/HCPSERVICE/p1941877974trial/relayrlk3";

	// 	// var url = "/destinations/UBER/v1/products?latitude="+lat+"&longitude="+long;
	// 	$.ajax({
	// 		type: "GET",
	// 		contentType: "application/json",
	// 		url: url,
	// 		// headers: {
	// 		// 	"Authorization": "Token OU0ijgdEoNof_wf01rFGFBOd_1ZayIOKFX8argni"

	// 		// },
	// 		success: function(data, textStatus, jqXHR) {

	// 			// alert("success to post");
	// 			// console.log("data");
	// 			console.log(data);
	// 			wifi = data.readings[0].value;
	// 			lumono = data.readings[3].value;
	// 			temp = 14 + (lumono/10);
	// 			batt = data.readings[5].value;
	// 			angulr_x = data.readings[4].value.x;
	// 			angulr_y = data.readings[4].value.y;
	// 			angulr_z = data.readings[4].value.z;
	// 			angulr_x = angulr_x * angulr_x;
	// 			angulr_y = angulr_y * angulr_y;
	// 			angulr_z = angulr_z * angulr_z;
	// 			modang = angulr_x + angulr_x + angulr_x;
	// 			modang = Math.sqrt(modang);
	// 			accelero_x = data.readings[1].value.x;
	// 			accelero_y = data.readings[1].value.y;
	// 			accelero_z = data.readings[1].value.z;
	// 			accelero_x = accelero_x * accelero_x;
	// 			accelero_y = accelero_y * accelero_y;
	// 			accelero_z = accelero_z * accelero_z;
	// 			modacc = accelero_x + accelero_x + accelero_x;
	// 			modacc = Math.sqrt(modacc);
	// 			oModel.setData({
	// 					sensor: [{
	// 							"sname": "Wireless",
	// 							"value": wifi,
	// 							"unit": "dbm"

	// 						}, {
	// 							"sname": "Lumonosity",
	// 							"value": lumono,
	// 							"unit": "L⊙"
	// 						}, {
	// 							"sname": "Battery",
	// 							"value": batt,
	// 							"unit": "kWh",
	// 						}, {
	// 							"sname": "Acceleration",
	// 							"value": modacc,
	// 							"unit": "m/s-2"
	// 						}, {
	// 							"sname": "Angular Speed",
	// 							"value": modang,
	// 							"unit": "m/s"
	// 						},
	// 						{
	// 							"sname": "Temperature",
	// 							"value": temp,
	// 							"unit": "C"
	// 						}

	// 					]

	// 				}

	// 			);

	// 			JSONModel.setData(data);
	// 			//alert("Success");

	// 		},
	// 		error: function() {
	// 			alert("Error");
	// 		}

	// 	});
	// 	// this.getView().byId("idCurrency1").bindElement("/Z_Treasury_Usd('USD')");
	// 	// this.getView().byId("idCurrency2").bindElement("/Z_Treasury_Cad('CAD')");
	// 	// this.getView().byId("idCurrency3").bindElement("/Z_Treasury_Eur('EUR')");
	// 	// this.getView().byId("idCurrency4").bindElement("/Z_Treasury_Aud('AUD')");
	// 	// this.getView().byId("idCurrency5").bindElement("/Z_Treasury_Eur('EUR')");
	// setInterval(this.refresh(), 60000);
		
	// },

	/**
	 * publish Detail NotFound event
	 */
	fireDetailNotFound: function() {
		this.getEventBus().publish("Detail", "NotFound");
	},

	/**
	 * Navigates back to main view
	 */
	onNavBack: function() {
		// This is only relevant when running on phone devices
		this.getRouter().myNavBack("main");
	},

	/**
	 * Detail view icon tab bar select event handler
	 */
	onDetailSelect: function(oEvent) {
		sap.ui.core.UIComponent.getRouterFor(this).navTo("detail", {
			entity: oEvent.getSource().getBindingContext().getPath().slice(1),
			tab: oEvent.getParameter("selectedKey")
		}, true);
	}

});