jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"SOLIST/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"SOLIST/test/integration/pages/App",
	"SOLIST/test/integration/pages/Browser",
	"SOLIST/test/integration/pages/Master",
	"SOLIST/test/integration/pages/Detail",
	"SOLIST/test/integration/pages/NotFound"
], function(Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "SOLIST.view."
	});

	sap.ui.require([
		"SOLIST/test/integration/NavigationJourneyPhone",
		"SOLIST/test/integration/NotFoundJourneyPhone",
		"SOLIST/test/integration/BusyJourneyPhone"
	], function() {
		QUnit.start();
	});
});