sap.ui.define(function() {
	"use strict";
 
	var Formatter = {
 
		status :  function (sStatus) {
				if (sStatus === "Completed") {
					return "Success";
				} else if (sStatus === "In Process") {
					return "Warning";
				} else if (sStatus === "Discontinued"){
					return "Error";
				} else {
					return "None";
				}
		},
		
		delivery :  function (sStatus) {
				if (sStatus === "") {
					return "Pending";
				} else {
					return sStatus;
				}
		},
		
				deliveryst :  function (sStatus) {
				if (sStatus === "") {
					return "Warning";
				} else {
					return "Success";
				}
		}
		
	};
 
	return Formatter;
 
}, /* bExport= */ true);












// sap.ui.define([], function() {
// 	"use strict";

// 	return {
// 		/**
// 		 * Rounds the currency value to 2 digits
// 		 *
// 		 * @public
// 		 * @param {string} sValue value to be formatted
// 		 * @returns {string} formatted currency value with 2 digits
// 		 */
// 		currencyValue: function(sValue) {
// 			if (!sValue) {
// 				return "";
// 			}

// 			return parseFloat(sValue).toFixed(2);
// 		}
// 	};

// });